<?php
define('BASE_PATH', rtrim(realpath(dirname(__FILE__)), "/") . '/');

require BASE_PATH . 'includes/settings.php';

if(session_status() == PHP_SESSION_NONE){
    session_start();
    session_cache_limiter("private_no_expire");
}

if ((!isset($_SESSION["password"])) || ($_SESSION["password"] != $password)) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ((isset($_POST["password"])) && (md5($_POST["password"]) == $password)) {
            $_SESSION["password"] = md5($_POST["password"]);
        } else {
            echo 'Wrong password?';exit();
        }
    } else {
        echo '<!doctype html><html><head><title>Login</title></head>
    <body><h1>Login</h1><p>You must be logged in to view this page.</p>
   <form action="" method="POST">
    <input type="password" placeholder="Password" name="password">
    <input type="submit" class="button">
   </form>
</body></html>';exit();
    }
}

$upload_category = $_POST['category'];

$target_dir = 'gallery/' . $upload_category . "/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        // echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        $message = "<p>This file is not a picture...</p>";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    $message = "<p>A file with that name already exists...</p>";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 10000000) {
    $message = "<p>The file was to big. Try to resize it before uploading.</p>";
    $uploadOk = 0;
}
// Allow certain file formats
if(!in_array($imageFileType, $allowed_file_types_arr)) {
    $message = "<p>You can only upload: JPG, JPEG, PNG og GIF filer.</p>" . $imageFileType;
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    $message .= "<p><b>The file was not uploaded.</b></p>";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        $message = "<p>". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.</p>";
        $message .= '<p><a href="admin.php" class="button">Upload another file</a></p>';
        $message .= '<p><a href="index.php?category='.$upload_category.'">Go to: '.$upload_category.'</a></p>';
        $_SESSION["selected_category"] = $upload_category;
    } else {
        $message ="<p>Error uploading file.</p>";
    }
    chmod($target_file, 0775);
}

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require BASE_PATH . 'templates/'.$template.'/upload_template.php';





